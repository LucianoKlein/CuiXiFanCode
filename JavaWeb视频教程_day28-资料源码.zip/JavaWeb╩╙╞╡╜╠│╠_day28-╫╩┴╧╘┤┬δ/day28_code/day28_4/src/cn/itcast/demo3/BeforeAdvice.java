package cn.itcast.demo3;

/**
 * 前置增强
 * @author cxf
 *
 */
public interface BeforeAdvice {
	public void before();
}
