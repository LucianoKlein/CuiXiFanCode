package cn.itcast.demo3;

// 服务员
public interface Waiter {
	// 服务
	public void serve();
	
	public void shouQian();
}
