package cn.itcast.demo3;

public interface AfterAdvice {
	public void after();
}
