package cn.itcast.demo2;

// 服务员
public interface Waiter {
	// 服务
	public void serve();
}
