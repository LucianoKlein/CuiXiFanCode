package cn.itcast.demo2;

public class ManWaiter implements Waiter {
	public void serve() {
		System.out.println("服务中...");
	}
}
