package cn.itcast.web.servlet;

import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 添加WebServlet注解
 * @author cxf
 *
 */
@WebServlet(urlPatterns="/AServlet", asyncSupported=true)
public class AServlet extends HttpServlet {
//	public static void main(String[] args) {
//		System.out.println("hello");
//		new Thread() {
//			public void run() {
//				
//			}
//		}.start();
//		
//		System.out.println("不知道上面的线程是否结束！");
//	}
	public void doGet(final HttpServletRequest req, final HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html;charset=utf-8");
		
	// 支持IE！如果输出不足512B，没有异步效果！
		for(int i = 0; i <= 512; i++) {
			resp.getWriter().print("a");
		}
		resp.getWriter().flush();
		
		/*
		 * 1. 得到异步上下文对象
		 */
		final AsyncContext ac = req.startAsync(req, resp);
		
		/*
		 * 2. 给上下文对象一个Runnable对象，让它执行这个任务
		 */
		ac.start(new Runnable() {
			public void run() {
				println("现在马上开始<br/>", resp);
				sleep(2000);
				for(char c = 'A'; c <= 'Z'; c++) {
					println(c+"", resp);
					sleep(250);
				}
				
				// 通知Tomcat我们已经执行结束了！
				ac.complete();
			}
		});
	}
	
	public void println(String text, HttpServletResponse resp) {
		try {
			resp.getWriter().print(text);
			resp.getWriter().flush();
		} catch (IOException e) {
		}
	}
	
	public void sleep(long ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
		}
	}
}
