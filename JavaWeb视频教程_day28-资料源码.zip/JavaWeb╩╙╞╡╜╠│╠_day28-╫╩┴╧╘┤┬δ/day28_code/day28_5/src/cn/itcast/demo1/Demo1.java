package cn.itcast.demo1;

import org.junit.Test;

public class Demo1 {
	@Test
	public void fun1() throws ClassNotFoundException {

	}
}
