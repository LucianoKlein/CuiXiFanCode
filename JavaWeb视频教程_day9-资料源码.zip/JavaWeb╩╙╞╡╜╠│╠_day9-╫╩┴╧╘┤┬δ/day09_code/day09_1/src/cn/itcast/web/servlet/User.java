package cn.itcast.web.servlet;

public class User {
	private String name = "zhangSan";
	
	public String getName() {
		return name;
	}

	public void hello() {
		System.out.println("hello");
	}
}
