package cn.itcast.bookstore.admin.category;

public class CategoryExcepiton extends Exception {

	public CategoryExcepiton() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryExcepiton(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CategoryExcepiton(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CategoryExcepiton(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
