package cn.itcast.bookstore.user.dao;

import org.apache.commons.dbutils.QueryRunner;

import cn.itcast.jdbc.TxQueryRunner;


/**
 * User持久层
 * @author cxf
 *
 */
public class UserDao {
	private QueryRunner qr = new TxQueryRunner();
}
