package cn.itcast.bookstore.user.service;

import cn.itcast.bookstore.user.dao.UserDao;

/**
 * User业务层
 * @author cxf
 *
 */
public class UserService {
	private UserDao userDao = new UserDao();
}
