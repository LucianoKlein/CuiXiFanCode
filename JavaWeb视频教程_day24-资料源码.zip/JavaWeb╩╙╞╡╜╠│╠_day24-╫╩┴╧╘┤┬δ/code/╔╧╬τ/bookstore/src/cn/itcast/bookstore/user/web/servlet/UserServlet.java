package cn.itcast.bookstore.user.web.servlet;

import cn.itcast.bookstore.user.service.UserService;
import cn.itcast.servlet.BaseServlet;

/**
 * User表述层
 */
public class UserServlet extends BaseServlet {
	private UserService userService = new UserService();
	
	
}
