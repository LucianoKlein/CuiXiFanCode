package cn.itcast.proxy;

public class WaiterImpl implements Waiter {
	public void serve() {
		System.out.println("服务...");
	}
}
