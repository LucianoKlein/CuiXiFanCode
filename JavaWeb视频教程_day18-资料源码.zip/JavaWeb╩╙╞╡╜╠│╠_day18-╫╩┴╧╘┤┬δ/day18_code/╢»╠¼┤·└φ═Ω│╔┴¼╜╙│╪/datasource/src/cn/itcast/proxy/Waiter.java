package cn.itcast.proxy;

public interface Waiter {
	public void serve();
}
