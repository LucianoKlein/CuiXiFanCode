package cn.itcast.bookstore.category.web.servlet.admin;

public class CategoryException extends Exception {

	public CategoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
