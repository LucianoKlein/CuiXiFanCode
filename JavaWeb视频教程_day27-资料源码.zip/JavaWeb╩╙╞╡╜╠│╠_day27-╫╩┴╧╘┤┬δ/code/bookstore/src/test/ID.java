package test;

public @interface ID {
	String value();
}
