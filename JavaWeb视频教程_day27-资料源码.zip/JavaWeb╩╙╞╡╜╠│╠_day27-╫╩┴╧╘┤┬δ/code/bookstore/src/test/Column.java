package test;

public @interface Column {
	String value();
}
