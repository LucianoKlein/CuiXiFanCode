package test;

public @interface Table {
	String value();
}
