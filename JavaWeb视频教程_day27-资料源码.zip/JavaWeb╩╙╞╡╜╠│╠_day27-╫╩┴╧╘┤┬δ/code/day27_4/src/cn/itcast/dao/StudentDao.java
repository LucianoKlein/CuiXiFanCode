package cn.itcast.dao;

import cn.itcast.domain.Student;

public interface StudentDao {
	void add(Student stu);
	void update(Student stu);
}
