package cn.itcast.dao.impl;

import cn.itcast.dao.StudentDao;
import cn.itcast.domain.Student;

public class StudentImpl2 implements StudentDao {

	@Override
	public void add(Student stu) {
		System.out.println("StudentImp2.add()");
	}

	@Override
	public void update(Student stu) { 
		System.out.println("StudentImp2.update()");
	}

}