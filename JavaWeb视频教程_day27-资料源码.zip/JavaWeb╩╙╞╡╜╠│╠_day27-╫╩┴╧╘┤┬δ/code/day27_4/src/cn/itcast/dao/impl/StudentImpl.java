package cn.itcast.dao.impl;

import cn.itcast.dao.StudentDao;
import cn.itcast.domain.Student;

public class StudentImpl implements StudentDao {

	@Override
	public void add(Student stu) {
		System.out.println("StudentImpl.add()");
	}

	@Override
	public void update(Student stu) { 
		System.out.println("StudentImpl.update()");
	}

}
