package cn.itcast.service;

public interface StudentService {
	void login();
}
