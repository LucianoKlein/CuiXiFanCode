package cn.itcast;

public class Demo1 {
	@Override
	public String toString() {
		return null;
	}
}
