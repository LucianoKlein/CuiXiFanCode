package cn.itcast.demo1;

@MyAnno1
public class Demo1 {
	@MyAnno1
	private String name;
	
	@MyAnno1
	public Demo1() {
		
	}
	
	@MyAnno1
	public void fun1() {
		
	}
	
	public void fun2(@MyAnno1 String name) {
		@MyAnno1
		String username = "hello";
	}
}

/**
 * 定义注解
 * @author cxf
 *
 */
@interface MyAnno1 {
}
