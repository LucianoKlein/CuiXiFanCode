package cn.itcast.demo5;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class Demo5 {

}

@Retention(RetentionPolicy.RUNTIME)
@interface MyAnno1 {
	
}
