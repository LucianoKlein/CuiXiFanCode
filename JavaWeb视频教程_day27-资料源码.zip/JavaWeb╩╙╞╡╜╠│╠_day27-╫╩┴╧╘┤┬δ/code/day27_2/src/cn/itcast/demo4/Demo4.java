package cn.itcast.demo4;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;


@MyAnno1
public class Demo4 {
	@MyAnno1
	public void fun1() {
		
	}
}

@Target(value={ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@interface MyAnno1 {
	
}
