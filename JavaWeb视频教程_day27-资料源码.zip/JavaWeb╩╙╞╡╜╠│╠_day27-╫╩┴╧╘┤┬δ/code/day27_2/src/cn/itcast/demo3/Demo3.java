package cn.itcast.demo3;

@MyAnno1(
	a=100,
	b="hello",
	c=MyEnum1.A,
	d=String.class,
	e=@MyAnno2(aa=200, bb="world"),
	f=100
)
public class Demo3 {

}

@interface MyAnno1 {
	int a();
	String b();
	MyEnum1 c();
	Class d();
	MyAnno2 e();
	int[] f();
}

@interface MyAnno2 {
	int aa();
	String bb();
}

enum MyEnum1 {
	A, B, C
}
