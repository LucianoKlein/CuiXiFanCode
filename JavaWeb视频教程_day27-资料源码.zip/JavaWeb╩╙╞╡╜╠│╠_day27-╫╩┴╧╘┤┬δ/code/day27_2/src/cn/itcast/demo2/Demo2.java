package cn.itcast.demo2;

@MyAnno1(age=100, name="zhangSan")
@MyAnno2(name="liSi", age=200)
@MyAnno3(100)
public class Demo2 {

}

@interface MyAnno1 {
	int age();
	String name();
}

@interface MyAnno2 {
	int age() default 100;
	String name();
}

@interface MyAnno3 {
	int value();
	String name() default "wangWu";
}