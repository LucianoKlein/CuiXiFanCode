package cn.itcast.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.itcast.domain.City;
import cn.itcast.domain.Province;
import cn.itcast.jdbc.TxQueryRunner;

public class Dao {
	private QueryRunner qr = new TxQueryRunner();
	/**
	 * 查询所有的省
	 * @return
	 */
	public List<Province> findAllProvince() {
		try {
			String sql = "select * from t_province";
			return qr.query(sql, new BeanListHandler<Province>(Province.class));
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * 查询指定省下的所有市
	 * @param proName
	 * @return
	 */
	public List<City> findByProvince(int pid) {
		try {
			String sql = "select * from t_city where pid=?";
			return qr.query(sql, new BeanListHandler<City>(City.class), pid);
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
