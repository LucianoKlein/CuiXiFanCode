package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import cn.itcast.dao.Dao;
import cn.itcast.domain.Province;

public class ProvinceServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		
		/*
		 * 1. 通过dao得到所有的省
		 * 2. 把List<Province>转换成json
		 * 3. 发送给客户端
		 */
		Dao dao = new Dao();
		List<Province> provinceList = dao.findAllProvince();
		String json = JSONArray.fromObject(provinceList).toString();
		
		response.getWriter().print(json);
	}
}
