/*
 * Copyright (C) 2007, 2009 XStream Committers.
 * All rights reserved.
 *
 * The software in this package is published under the terms of the BSD
 * style license a copy of which has been included with this distribution in
 * the LICENSE.txt file.
 * 
 * Created on 13. September 2007 by Joerg Schaible
 */
package com.thoughtworks.xstream.tools.benchmark.xmlfriendly.model;

/**
 * Class with 100 fields containing each 5 underscores in the name.
 * 
 * @author J&ouml;rg Schaible
 */
public class A100_Fields {

    String _____000;
    String _____001;
    String _____002;
    String _____003;
    String _____004;
    String _____005;
    String _____006;
    String _____007;
    String _____008;
    String _____009;
    String _____010;
    String _____011;
    String _____012;
    String _____013;
    String _____014;
    String _____015;
    String _____016;
    String _____017;
    String _____018;
    String _____019;
    String _____020;
    String _____021;
    String _____022;
    String _____023;
    String _____024;
    String _____025;
    String _____026;
    String _____027;
    String _____028;
    String _____029;
    String _____030;
    String _____031;
    String _____032;
    String _____033;
    String _____034;
    String _____035;
    String _____036;
    String _____037;
    String _____038;
    String _____039;
    String _____040;
    String _____041;
    String _____042;
    String _____043;
    String _____044;
    String _____045;
    String _____046;
    String _____047;
    String _____048;
    String _____049;
    String _____050;
    String _____051;
    String _____052;
    String _____053;
    String _____054;
    String _____055;
    String _____056;
    String _____057;
    String _____058;
    String _____059;
    String _____060;
    String _____061;
    String _____062;
    String _____063;
    String _____064;
    String _____065;
    String _____066;
    String _____067;
    String _____068;
    String _____069;
    String _____070;
    String _____071;
    String _____072;
    String _____073;
    String _____074;
    String _____075;
    String _____076;
    String _____077;
    String _____078;
    String _____079;
    String _____080;
    String _____081;
    String _____082;
    String _____083;
    String _____084;
    String _____085;
    String _____086;
    String _____087;
    String _____088;
    String _____089;
    String _____090;
    String _____091;
    String _____092;
    String _____093;
    String _____094;
    String _____095;
    String _____096;
    String _____097;
    String _____098;
    String _____099;
}
