package cn.itcast.fn;

public class MyFunction {
	public static String fun() {
		return "传智播客之EL函数库";
	}
}
