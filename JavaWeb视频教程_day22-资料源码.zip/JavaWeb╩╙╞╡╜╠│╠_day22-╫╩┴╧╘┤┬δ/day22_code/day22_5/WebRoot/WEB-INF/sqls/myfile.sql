CREATE TABLE tb_myfile(
	fid CHAR(32) PRIMARY KEY,
	filepath VARCHAR(100),
	framename VARCHAR(100),
	uploadtime CHAR(19),
	cnt INT,
	filesize LONG
);

