package cn.itcast.demo3;

public class User {
	
}
